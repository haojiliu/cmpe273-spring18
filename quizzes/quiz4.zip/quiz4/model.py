import os
import sys
from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine

Base = declarative_base()

class Wallet(Base):
    __tablename__ = 'wallet'
    # Here we define columns for the table address.
    # Notice that each column is also a normal Python instance attribute.
    id = Column(Integer, primary_key=True)
    balance = Column(String(250), nullable=False)
    coin_symbol = Column(Integer, nullable=False)

class Transaction(Base):
    __tablename__ = 'transaction'
    # Here we define columns for the table address.
    # Notice that each column is also a normal Python instance attribute.
    txn_hash = Column(String(250), primary_key=True)
    status = Column(String(250), nullable=False)
    from_wallet = Column(String(250), nullable=False)
    to_wallet = Column(String(250), nullable=False)
    amount = Column(Integer, nullable=False)
    time_stamp = Column(String(250), nullable=False)
