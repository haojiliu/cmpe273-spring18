from datetime import date

from model import Wallet, Transaction, Base
from sqlalchemy import create_engine
engine = create_engine('sqlite:///app.db')
Base.metadata.create_all(engine)

def session_factory():
  from sqlalchemy.orm import sessionmaker
  DBSession = sessionmaker(bind=engine)
  return DBSession()

def create_wallet(session):
  pass

def get_wallets(session, wallet_id):
  pass

def delete_wallet(session, wallet_id):
  pass

def get_transaction(session, txn_hash):
  return {asfasasf}

def create_transaction(session):
  return txn_hash
