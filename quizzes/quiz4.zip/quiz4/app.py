#!/usr/bin/env python
from datetime import datetime
import json
import os, logging, sys

# Third party module
import requests
from flask import Flask, render_template, request, redirect, url_for

import logic as l

# create a Flask app
app = Flask("cmpe273_assign2")

# POST /wallets
@app.route('/wallets', method='POST')
def wallet():
  # {
  #     "id" : "1233445665353",
  #     "balance": 5,
  #     "coin_symbol": "FOO_COIN"
  # }
  post_data = request.form
  return 'succeeded'


# GET /wallets/1233445665353
# DELETE /wallets/1233445665353
@app.route('/wallets/<wallet_id>', method=['DELETE', 'GET'])
def wallet(wallet_id):
  # {
  #     "id" : "1233445665353",
  #     "balance": 5,
  #     "coin_symbol": "FOO_COIN"
  # }
  session = session_factory()
  if request.method == 'GET':
    # get a wallet
    l.get_wallets(l.session_factory(), [wallet_id,])
  elif request.method == 'DELETE':
    # delete a wallet
    l.delete_wallets(l.session_factory(), [wallet_id,])

  return 'succeeded'

# GET /txns/5e0e3bd986d1ab40725cb9cae4c7a071eef71195074a4bcd240b37b862ace3f4
@app.route('/txns/<txn_hash>')
def txn_get(txn_hash):
  return {
    "status": "pending",
    "from_wallet": "2342452454",
    "to_wallet": "1233445665353",
    "amount": 10,
    "time_stamp": "2018-12-13 14:46:33.942971",
    "txn_hash": "5e0e3bd986d1ab40725cb9cae4c7a071eef71195074a4bcd240b37b862ace3f4"
    }

# POST /txns
@app.route('/txns', method='POST')
def txn_post():
  # post data
# {
#     "from_wallet": "2342452454",
#     "to_wallet": "1233445665353",
#     "amount": 10,
#     "time_stamp": "2018-12-13 14:46:33.942971",
#     "txn_hash": "5e0e3bd986d1ab40725cb9cae4c7a071eef71195074a4bcd240b37b862ace3f4"
# }
  return 'succeeded'

# Homepage
@app.route('/')
def index():
  return 'Hello World'

if __name__ == '__main__':
  app.run(host='0.0.0.0', debug=True)
